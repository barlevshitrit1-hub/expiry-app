// Vercel serverless function. Set ANTHROPIC_API_KEY in the project settings.
module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).end();
  const { prompt, images } = req.body || {};
  if (typeof prompt !== "string" || prompt.length > 4000 || !Array.isArray(images) || images.length < 1 || images.length > 3)
    return res.status(400).json({ error: "bad request" });
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: "claude-haiku-5-5", max_tokens: 400,
        messages: [{ role: "user", content: [
          ...images.map(d => ({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: d } })),
          { type: "text", text: prompt }] }]
      })
    });
    if (!r.ok) return res.status(502).json({ error: "upstream" });
    const data = await r.json();
    const text = (data.content || []).map(b => b.text || "").join("");
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return res.status(502).json({ error: "no json" });
    res.status(200).json(JSON.parse(m[0]));
  } catch (e) { res.status(500).json({ error: "failed" }); }
};
